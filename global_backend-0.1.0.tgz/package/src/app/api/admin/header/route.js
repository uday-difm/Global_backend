import { NextResponse } from "next/server";
import { checkSitePermission } from "@/lib/apiAuth";
import { settingsService } from "@/services/settings.service";
import { handleApiError } from "@/core/errors";

export async function GET(req) {
  const auth = await checkSitePermission(req, "EDITOR");
  if (auth.error) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  try {
    const header = await settingsService.getSettingsField(auth.siteId, "header");
    return NextResponse.json({ success: true, header });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PUT(req) {
  const auth = await checkSitePermission(req, "EDITOR");
  if (auth.error) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  try {
    const body = await req.json();
    const result = await settingsService.updateSettingsField(
      auth.siteId,
      "header",
      body,
      auth.user.id
    );

    return NextResponse.json({ success: true, header: result });
  } catch (err) {
    return handleApiError(err);
  }
}

