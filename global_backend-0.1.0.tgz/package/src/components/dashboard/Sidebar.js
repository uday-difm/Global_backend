"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";
import { useState } from "react";

import {
  LayoutDashboard,
  ImageIcon,
  FileText,
  Newspaper,
  Briefcase,
  Settings,
  Users,
  Inbox,
  Quote,
  HelpCircle,
  UsersRound,
  Database,
  ArrowLeftRight,
  PanelBottom,
  PanelTop,
  ShieldCheck,
  Phone,
  Megaphone,
  BarChart2,
  Scale,
  Menu,
  Mail,
  Activity,
  Bell,
  Fingerprint,
  Terminal,
  ChevronDown,
  ChevronRight,
} from "lucide-react";

const ROLE_LEVEL = {
  SUPERADMIN: 5,
  ADMIN: 4,
  EDITOR: 3,
  AUTHOR: 2,
  VIEWER: 1,
};

const sections = [
  {
    title: "Overview",
    links: [
      {
        href: "/dashboard",
        label: "Dashboard",
        icon: LayoutDashboard,
        minRole: "VIEWER",
      },
      {
        href: "/leads",
        label: "Leads CRM",
        icon: Inbox,
        minRole: "EDITOR",
      },
      {
        href: "/visitors",
        label: "Analytics",
        icon: BarChart2,
        minRole: "VIEWER",
      },
    ],
  },

  {
    title: "Content",
    links: [
      {
        href: "/pages",
        label: "Pages",
        icon: FileText,
        minRole: "EDITOR",
      },
      {
        href: "/blogs",
        label: "Blogs",
        icon: Newspaper,
        minRole: "AUTHOR",
      },
      {
        href: "/services",
        label: "Services",
        icon: Briefcase,
        minRole: "EDITOR",
      },
      {
        href: "/media",
        label: "Media",
        icon: ImageIcon,
        minRole: "AUTHOR",
      },
    ],
  },

  {
    title: "Website",
    links: [
      {
        href: "/navigation",
        label: "Navigation",
        icon: Menu,
        minRole: "EDITOR",
      },
      {
        href: "/header",
        label: "Header Builder",
        icon: PanelTop,
        minRole: "ADMIN",
      },
      {
        href: "/footer",
        label: "Footer Builder",
        icon: PanelBottom,
        minRole: "ADMIN",
      },
      {
        href: "/cta",
        label: "CTA & Popups",
        icon: Megaphone,
        minRole: "ADMIN",
      },
      {
        href: "/contact",
        label: "Contact",
        icon: Phone,
        minRole: "EDITOR",
      },
      {
        href: "/legal",
        label: "Legal Pages",
        icon: Scale,
        minRole: "EDITOR",
      },
    ],
  },

  {
    title: "People",
    links: [
      {
        href: "/team",
        label: "Team",
        icon: UsersRound,
        minRole: "EDITOR",
      },
      {
        href: "/testimonials",
        label: "Testimonials",
        icon: Quote,
        minRole: "EDITOR",
      },
      {
        href: "/faq",
        label: "FAQs",
        icon: HelpCircle,
        minRole: "EDITOR",
      },
    ],
  },

  {
    title: "System",
    links: [
      {
        href: "/users",
        label: "Users",
        icon: Users,
        minRole: "ADMIN",
      },
      {
        href: "/email",
        label: "Email",
        icon: Mail,
        minRole: "ADMIN",
      },
      {
        href: "/security",
        label: "Security",
        icon: ShieldCheck,
        minRole: "ADMIN",
      },
      {
        href: "/redirects",
        label: "Redirects",
        icon: ArrowLeftRight,
        minRole: "ADMIN",
      },
      {
        href: "/notifications",
        label: "Notifications",
        icon: Bell,
        minRole: "ADMIN",
      },
    ],
  },
];

function canSee(userRole, minRole) {
  return (ROLE_LEVEL[userRole] || 0) >= (ROLE_LEVEL[minRole] || 0);
}

function SidebarLink({ href, label, icon: Icon, pathname }) {
  const isActive =
    pathname === href || (href !== "/dashboard" && pathname.startsWith(href));

  return (
    <Link
      href={href}
      className={`flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[11px] font-medium transition-all ${
        isActive
          ? "bg-indigo-50 text-indigo-700 border border-indigo-100 shadow-sm"
          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
      }`}
    >
      <Icon
        size={14}
        className={isActive ? "text-indigo-600" : "text-gray-400"}
      />
      <span className="truncate">{label}</span>
    </Link>
  );
}

export default function Sidebar() {
  const pathname = usePathname();
  const { data: session } = useSession();

  const [advancedOpen, setAdvancedOpen] = useState(false);

  const userRole = session?.user?.globalRole || "VIEWER";

  return (
    <aside className="hidden md:flex md:w-56 md:flex-col border-r bg-white">
      {/* Header */}
      <div className="border-b px-4 py-3">
        <h1 className="text-base font-bold tracking-tight text-gray-900">
          Global CMS
        </h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-3">
        {sections.map((section) => {
          const visibleLinks = section.links.filter((link) =>
            canSee(userRole, link.minRole),
          );

          if (!visibleLinks.length) return null;

          return (
            <div key={section.title}>
              <h5 className="px-2.5 mb-1 text-[9px] font-bold uppercase tracking-[0.18em] text-gray-400">
                {section.title}
              </h5>

              <div className="space-y-0.5">
                {visibleLinks.map((link) => (
                  <SidebarLink key={link.href} {...link} pathname={pathname} />
                ))}
              </div>
            </div>
          );
        })}

        {/* Advanced */}
        {canSee(userRole, "ADMIN") && (
          <div>
            <button
              onClick={() => setAdvancedOpen(!advancedOpen)}
              className="flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-[11px] font-medium text-gray-600 hover:bg-gray-50"
            >
              <span>Advanced</span>

              {advancedOpen ? (
                <ChevronDown size={14} />
              ) : (
                <ChevronRight size={14} />
              )}
            </button>

            {advancedOpen && (
              <div className="mt-1 space-y-0.5">
                <SidebarLink
                  href="/backup"
                  label="Backup & Restore"
                  icon={Database}
                  pathname={pathname}
                />

                <SidebarLink
                  href="/compliance"
                  label="Compliance"
                  icon={Fingerprint}
                  pathname={pathname}
                />

                <SidebarLink
                  href="/performance"
                  label="Performance"
                  icon={Activity}
                  pathname={pathname}
                />

                <SidebarLink
                  href="/dev"
                  label="Developer Tools"
                  icon={Terminal}
                  pathname={pathname}
                />

                <SidebarLink
                  href="/settings"
                  label="Settings"
                  icon={Settings}
                  pathname={pathname}
                />
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Footer */}
      <div className="border-t px-4 py-2.5 bg-gray-50">
        <div className="flex items-center justify-between">
          <span className="text-[9px] text-gray-400 font-medium">CMS v1.0</span>

          <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-indigo-700">
            {userRole}
          </span>
        </div>
      </div>
    </aside>
  );
}
