"use client";

import { useCreateBlockNote } from "@blocknote/react";
import { BlockNoteView } from "@blocknote/mantine";
import "@blocknote/core/fonts/inter.css";
import "@blocknote/mantine/style.css";

export default function BlockEditor({
  initialContent,
  onChangeHtml,
  onChangeJson,
}) {
  // Initialize the editor with existing JSON blocks if available
  const editor = useCreateBlockNote({
    initialContent: initialContent ? JSON.parse(initialContent) : undefined,
  });

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden bg-white z-10">
      <BlockNoteView
        editor={editor}
        theme="light"
        onChange={async () => {
          // 1. Save the raw JSON blocks (best for saving to DB for future editing)
          const jsonBlocks = JSON.stringify(editor.document);
          if (onChangeJson) onChangeJson(jsonBlocks);

          // 2. Generate clean HTML (for the layman-litigation frontend)
          const html = await editor.blocksToHTMLLossy(editor.document);
          if (onChangeHtml) onChangeHtml(html);
        }}
      />
    </div>
  );
}
